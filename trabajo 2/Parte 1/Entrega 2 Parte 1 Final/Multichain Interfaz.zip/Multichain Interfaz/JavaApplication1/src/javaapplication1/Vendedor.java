package javaapplication1;

public class Vendedor {
    // Propiedades
    public String nombre;
    public String telefono;
    public Double ganancias;

    public Vendedor(String nombre, String telefono, Double ganancia){
        this.nombre = nombre;
        this.telefono = telefono;
        this.ganancias = ganancia;
    }

}
