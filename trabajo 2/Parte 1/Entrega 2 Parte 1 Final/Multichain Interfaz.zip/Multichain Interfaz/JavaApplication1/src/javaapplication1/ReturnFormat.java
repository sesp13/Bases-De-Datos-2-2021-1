package javaapplication1;

public class ReturnFormat{
    public String mensaje;
    public Boolean esError;
    public ReturnFormat(String mensaje, Boolean esError){
        this.mensaje = mensaje;
        this.esError = esError;
    }
}