package javaapplication1;

public class Ganancia {
    public Double valor;
    public String vendedor;

    public Ganancia(String vendedor, Double valor) {
        this.valor = valor;
        this.vendedor = vendedor;
    }
}
