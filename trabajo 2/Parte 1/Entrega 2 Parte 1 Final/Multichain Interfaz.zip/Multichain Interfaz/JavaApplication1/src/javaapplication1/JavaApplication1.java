
package javaapplication1;

import java.util.*;
import multichain.command.*;
import multichain.object.*;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class JavaApplication1 {
        ApiMultichainBD2 usuario;
    public static void main(String[] args) {
        
        
        new inicio();
        
    }
    
}
