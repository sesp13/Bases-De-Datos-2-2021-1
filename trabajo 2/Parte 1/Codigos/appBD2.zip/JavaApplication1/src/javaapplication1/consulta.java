package javaapplication1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class consulta implements ActionListener{
    
        private static JPanel panel;
        private static JButton volver;
        private static JFrame frame;
        
    
    public consulta(){                
     
        volver = new JButton("Volver");
        volver.addActionListener(this);
        volver.setBounds(230,110,90,25);
        
        panel = new JPanel();
        panel.setBorder(BorderFactory.createEmptyBorder(300,300,10,300));
        panel.setLayout(null);
        panel.add(volver);
        
        frame = new JFrame();
        frame.add(panel, BorderLayout.CENTER);
        frame.setSize(350,200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Consulta");
        frame.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e){
        frame.dispose();
        if(e.getSource()==volver){
            inicio inicio = new inicio();
        }
    }
}


