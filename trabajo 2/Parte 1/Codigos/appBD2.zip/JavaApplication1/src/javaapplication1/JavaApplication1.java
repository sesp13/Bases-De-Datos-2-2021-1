
package javaapplication1;

public class JavaApplication1 {

    public static void main(String[] args) {
        new inicio();
    }
    
}
