package models;

public class Ciudad {
    public Number cod;
    public String nom;
    public Number midep;

    public Ciudad(Number cod, String nom, Number midep){
        this.cod = cod;
        this.nom = nom;
        this.midep = midep;
    }
}
