package models;

public class Departamento {

    public Number cod;
    public String nom;

    public Departamento(Number cod, String nom){
        this.cod = cod;
        this.nom = nom;
    }

}
