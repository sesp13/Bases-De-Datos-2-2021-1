package models;

public class MongoVentas {
    public String nombreCiudad;
    public Number valorVentas;
    public String mejorVendedor;
}
