package models;

public class Venta {
    public Number miprod;
    public Number nro_unidades;

    public Venta(Number miprod, Number nro_unidades) {
        this.miprod = miprod;
        this.nro_unidades = nro_unidades;
    }

}