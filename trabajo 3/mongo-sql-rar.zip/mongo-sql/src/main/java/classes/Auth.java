package classes;

public class Auth {

    //Datos de autenticacion Oracle
    public String pathDriverOracle = "jdbc:oracle:thin:@localhost:1521:xe";
    public String usuarioOrcale = "admin";
    public String passwordOracle = "admin";

    // public String getPasswordOracle() {
    //   return this.passwordOracle;
    // }

    // public String getPathDriverOracle() {
    //   return this.pathDriverOracle;
    // }

    // public String getUsuarioOrcale() {
    //   return this.usuarioOrcale;
    // }

    //Datos de autenticacion Mongo

}
