import java.sql.*;

import classes.Inicio;
import classes.SqlGenerator;
import models.MongoClass;
public class Main {
    public static void main(String[] args) {

        SqlGenerator generador = new SqlGenerator();
        new Inicio();


    } // Fin del main
} // Fin de la clase

