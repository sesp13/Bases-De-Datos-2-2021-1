import classes.MongoConnection;
import classes.Inicio;
import classes.SqlGenerator;
import ModelsM.BusquedaMongo;

public class Main {
    public static void main(String[] args) {

        //BusquedaMongo busqueda = new BusquedaMongo(connMongo.collection);

        new Inicio();

        // connMongo.guardarDocumento();

    } // Fin del main
} // Fin de la clase
