package controllersMongo;

public class MongoEmpleado {
}
