package ModelsM;

public class CiudadM {
    String nombreCiudad;
    Double valorVentas;
    public CiudadM(String nombreCiudad, Double valorVentas){
        this.nombreCiudad=nombreCiudad;
        this.valorVentas=valorVentas;
    }
}
