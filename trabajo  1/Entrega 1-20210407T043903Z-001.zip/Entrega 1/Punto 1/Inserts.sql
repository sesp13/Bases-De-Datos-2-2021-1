--Insertar esta tabla en la base de datos para correr el procedimiento del primer punto
CREATE TABLE cerdoAux(
    cod NUMBER(8),
    nombre VARCHAR(20),
    pesokilos NUMBER(8),
    seleccionado NUMBER(1)
);
